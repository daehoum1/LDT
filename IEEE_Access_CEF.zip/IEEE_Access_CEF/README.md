# IEEE Access CEF manuscript

Upload this directory, or the provided ZIP archive, to Overleaf while preserving
the directory structure. Set `main.tex` as the main document and select
pdfLaTeX as the compiler.

The package includes the IEEE Access class and font resources, the IEEEtran
bibliography style, all figures and author photographs, all tables, and the
unchanged CEF bibliography database. Publication-history and DOI fields in
`main.tex` are editorial placeholders.
