ETRI Journal LaTeX Starter
==========================

Files
-----
main.tex            Clean anonymous manuscript starter
references.bib      BibTeX database
WileyNJDv5.cls      Wiley NJDv5 class from the supplied template
NJDnatbib.sty        Wiley bibliography support
wileyNJD-AMS.bst    AMS-style numbered bibliography
figures/             Put figures here

Overleaf
--------
1. New Project -> Upload Project -> upload ETRI_Journal_Starter.zip
2. Main document: main.tex
3. Default compiler: pdfLaTeX works with the included Times2COL setup.

STIX option
-----------
The supplied Wiley template includes local STIX font files, but font files are
not redistributed in this starter. If you want to use the original STIX2COL
setup, copy the original template's Fonts/Stix folder into the project, change

  \documentclass[AMS,Times2COL]{WileyNJDv5}

to

  \documentclass[AMS,STIX2COL]{WileyNJDv5}

and set the Overleaf compiler to XeLaTeX.

Submission note
---------------
For the initial double-anonymous manuscript, keep author names, affiliations,
correspondence details, funding, acknowledgments, and other identifying
information out of main.tex.
